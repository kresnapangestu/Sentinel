Reserved for framework-agnostic helper functions shared across features
(formatting, guards, etc.). Nothing global was needed for this page yet.
