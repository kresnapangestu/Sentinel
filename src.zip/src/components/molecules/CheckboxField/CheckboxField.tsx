import { InputHTMLAttributes, forwardRef, ReactNode } from "react";
import { Checkbox } from "@/components/atoms/Checkbox";
import { Label } from "@/components/atoms/Label";
import styles from "./CheckboxField.module.css";

export interface CheckboxFieldProps
  extends InputHTMLAttributes<HTMLInputElement> {
  id: string;
  children: ReactNode;
}

/** Pairs a Checkbox atom with an inline Label sharing the same id. */
export const CheckboxField = forwardRef<HTMLInputElement, CheckboxFieldProps>(
  ({ id, children, className, ...rest }, ref) => {
    const classNames = [styles.wrapper, className].filter(Boolean).join(" ");
    return (
      <div className={classNames}>
        <Checkbox id={id} ref={ref} {...rest} />
        <Label htmlFor={id} className={styles.label}>
          {children}
        </Label>
      </div>
    );
  },
);

CheckboxField.displayName = "CheckboxField";
