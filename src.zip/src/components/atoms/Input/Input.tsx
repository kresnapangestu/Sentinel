import { forwardRef, InputHTMLAttributes } from "react";
import styles from "./Input.module.css";

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  hasError?: boolean;
}

/**
 * Base input atom. Purely presentational and forwardRef-enabled so it can
 * be registered directly with React Hook Form.
 */
export const Input = forwardRef<HTMLInputElement, InputProps>(
  ({ hasError = false, className, ...rest }, ref) => {
    const classNames = [styles.input, hasError ? styles.error : "", className]
      .filter(Boolean)
      .join(" ");

    return (
      <input
        ref={ref}
        className={classNames}
        aria-invalid={hasError || undefined}
        {...rest}
      />
    );
  },
);

Input.displayName = "Input";
