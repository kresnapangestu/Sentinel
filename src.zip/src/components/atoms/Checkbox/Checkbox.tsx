import { forwardRef, InputHTMLAttributes } from "react";
import styles from "./Checkbox.module.css";

export type CheckboxProps = InputHTMLAttributes<HTMLInputElement>;

/**
 * Base checkbox atom. Presentational only; label pairing happens in the
 * CheckboxField molecule.
 */
export const Checkbox = forwardRef<HTMLInputElement, CheckboxProps>(
  ({ className, ...rest }, ref) => {
    const classNames = [styles.checkbox, className].filter(Boolean).join(" ");
    return <input ref={ref} type="checkbox" className={classNames} {...rest} />;
  },
);

Checkbox.displayName = "Checkbox";
