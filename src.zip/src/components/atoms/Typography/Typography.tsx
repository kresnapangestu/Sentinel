import { ElementType, HTMLAttributes, ReactNode } from "react";
import styles from "./Typography.module.css";

export type TypographyVariant =
  | "display"
  | "h1"
  | "h2"
  | "body"
  | "bodySmall"
  | "caption";

export interface TypographyProps extends HTMLAttributes<HTMLElement> {
  variant?: TypographyVariant;
  as?: ElementType;
  children: ReactNode;
}

const defaultElement: Record<TypographyVariant, ElementType> = {
  display: "h1",
  h1: "h1",
  h2: "h2",
  body: "p",
  bodySmall: "p",
  caption: "span",
};

/** Typography atom centralizing the type scale so styles never drift. */
export function Typography({
  variant = "body",
  as,
  className,
  children,
  ...rest
}: TypographyProps) {
  const Component = as ?? defaultElement[variant];
  const classNames = [styles[variant], className].filter(Boolean).join(" ");

  return (
    <Component className={classNames} {...rest}>
      {children}
    </Component>
  );
}
