import { ButtonHTMLAttributes, ReactNode } from "react";
import styles from "./IconButton.module.css";

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  icon: ReactNode;
  "aria-label": string;
}

/**
 * Icon-only button atom. aria-label is required (not optional) so every
 * usage stays accessible by construction.
 */
export function IconButton({
  icon,
  className,
  type = "button",
  ...rest
}: IconButtonProps) {
  console.log("iconButton", className);
  const classNames = [styles.iconButton, className].filter(Boolean).join(" ");
  return (
    <button type={type} className={classNames} {...rest}>
      {icon}
    </button>
  );
}
