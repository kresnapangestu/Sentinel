import { LabelHTMLAttributes, ReactNode } from "react";
import styles from "./Label.module.css";

export interface LabelProps extends LabelHTMLAttributes<HTMLLabelElement> {
  children: ReactNode;
}

/** Base label atom, always paired with a form control via htmlFor. */
export function Label({ className, children, ...rest }: LabelProps) {
  const classNames = [styles.label, className].filter(Boolean).join(" ");
  return (
    <label className={classNames} {...rest}>
      {children}
    </label>
  );
}
