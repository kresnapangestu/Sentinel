import { ReactNode } from "react";
import { Button } from "@/components/atoms/Button";
import { ThemeToggle } from "@/components/molecules/ThemeToggle";
import styles from "./AuthTemplate.module.css";

export interface AuthTemplateProps {
  marketingSlot: ReactNode;
  children: ReactNode;
}

/**
 * Page-level template: owns the split-screen layout and responsive
 * breakpoints only. Content is injected via slots so this template has
 * no knowledge of auth-specific logic.
 */
export function AuthTemplate({ marketingSlot, children }: AuthTemplateProps) {
  return (
    <main className={styles.shell}>
      <div className={styles.card}>
        <div className={styles.marketingColumn}>{marketingSlot}</div>

        <div className={styles.formColumn}>
          <div className={styles.topBar}>
            <ThemeToggle className={styles.signInBadge} />
          </div>
          <div className={styles.formContent}>{children}</div>
        </div>
      </div>
    </main>
  );
}
