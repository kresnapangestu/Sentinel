Hooks reused across multiple features.

- `useTheme.ts` — reads/toggles the current theme via ThemeContext. Used
  by `ThemeToggle` (and anything else that ever needs theme awareness).

The login flow's own hook stays in `features/auth/hooks` since it isn't
reused outside that feature.
