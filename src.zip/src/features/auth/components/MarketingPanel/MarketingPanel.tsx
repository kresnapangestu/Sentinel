import { Typography } from "@/components/atoms/Typography";
import styles from "./MarketingPanel.module.css";
import Image from "next/image";

/**
 * Left-hand brand/marketing panel. Static presentational content --
 * copy and slide count are the only things likely to change here.
 */
export function MarketingPanel() {
  return (
    <section
      className={styles.panel + " bg-[url('/background-login.webp')]"}
      aria-label="Product highlights"
    >
      <div className={styles.brand}>
        <Typography variant="h2" as="span" className={styles.brandName}>
          Sentinel
        </Typography>
      </div>
      <div className={styles.copy}>
        <Typography variant="display" className={styles.tagline}>
          Monitor Network.
          <br />
          Detect Anomalies.
          <br />
          Make Better Decisions.
        </Typography>

        <Typography variant="body" className={styles.description}>
          A web-based dashboard for monitoring telecommunication KPIs and
          comparing Isolation Forest and Z-Score methods for early anomaly
          detection.
        </Typography>
      </div>
    </section>
  );
}
