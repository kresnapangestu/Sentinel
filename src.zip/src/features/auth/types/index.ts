/**
 * Domain types for the auth feature. Kept separate from the Zod schema's
 * inferred type so the domain model can evolve independently of the
 * validation layer if needed later.
 */
export interface AuthenticatedUser {
  id: string;
  email: string;
  name: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
  rememberMe: boolean;
}

export interface LoginResult {
  user: AuthenticatedUser;
  token: string;
}
