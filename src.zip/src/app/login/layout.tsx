import type { ReactNode } from "react";

// Global tokens are imported once in the root layout (src/app/layout.tsx),
// which also owns the <html data-theme> attribute the tokens key off of.
export default function LoginLayout({ children }: { children: ReactNode }) {
  return children;
}
