import type { Metadata } from "next";
import { AuthTemplate } from "@/components/templates/AuthTemplate";
import { MarketingPanel, LoginForm } from "@/features/auth";
import { Typography } from "@/components/atoms/Typography";
import styles from "./page.module.css";

export const metadata: Metadata = {
  title: "Sign in | Sentinel",
  description: "Sign in to your Sentinel account.",
};

export default function LoginPage() {
  return (
    <AuthTemplate marketingSlot={<MarketingPanel />}>
      <header className={styles.header}>
        <Typography variant="h1">Welcome to Sentinel!</Typography>
        <Typography variant="bodySmall" as="p">
          Sign in to your account
        </Typography>
      </header>
      <LoginForm />
    </AuthTemplate>
  );
}
