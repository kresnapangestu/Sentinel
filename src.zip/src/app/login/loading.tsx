import styles from "./loading.module.css";

/** Route-level loading skeleton shown while the login route streams in. */
export default function LoginLoading() {
  return (
    <div className={styles.wrapper} role="status" aria-label="Loading">
      <div className={styles.spinner} />
    </div>
  );
}
