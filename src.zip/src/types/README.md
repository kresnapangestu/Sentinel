Reserved for global TypeScript types shared across features. Auth-specific
types live in features/auth/types since they are not yet reused elsewhere.
